(function($){
	var defaults = {
		showOnClick: true,
		tipsElement: '#GTips',
		fitWidth: false
	};

	var GUID = 0;
	var selectedGUID = -1;

	function isTypeOf(obj) {
		return Object.prototype.toString.apply(obj);
	}

	function isArray(obj) {
		return isTypeOf(obj).toLowerCase() === '[object array]';
	}

	function isString(obj) {
		return isTypeOf(obj).toLowerCase() === '[object string]';
	}

	function addSelectedStyle() {
		$(this).addClass("selected");
		$('#submit').removeClass("grey");
		$('#submit').addClass("red");
	}

	function removeSelectedStyle() {
		$(this).removeClass("selected");
		$('#submit').removeClass("red");
		$('#submit').addClass("grey");
	}

	function onItemSelected() {
		var gtips = cache[selectedGUID];
		var index = $(this).index();
		var elem = gtips.$elem;
		var data = gtips.data['data'];
		$(elem).find('.selected-item').text(data[index].name);
		addSelectedStyle.apply(elem);
		$(elem).data("gtips",data[index].value);
		gtips.hide();
	}

	var GTips = function(elem,data,options) {
		var self = this,
			tipsElement;

		self.$elem = $(elem),
		self.data = data,
		self.options = $.extend({},defaults);

		if( options ) {
			this.options = $.extend(self.options,options);
		} 

		options = this.options;

		self.isShow = false;
		
		self.$elem.guid = GUID++;

		if( options.showOnClick ) {
			this.$elem.click(function(){
				if( !self.isShow || selectedGUID != self.$elem.guid ) {
					self.show();
				} else {
					self.hide();
				}
			});
		}

		tipsElement = $(options.tipsElement);
		if( tipsElement.size() == 0 ) {
			self.createTips();
		}
		self.tipsElement = $(options.tipsElement);
	}

	GTips.prototype = {
		show: function() {
			var self = this;
			self.isShow = true;
			self.renderData();

			self.calcPos();
			if( selectedGUID != self.$elem.guid ) {
				
				selectedGUID = self.$elem.guid;
			}
			
			self.tipsElement.css("visibility","visible");

		},
		hide: function() {
			var self = this;
			self.isShow = false;
			self.tipsElement.css("visibility","hidden");
		},
		toggle: function() {
			var self = this;
			if ( self.isShow && selectedGUID == self.$elem.guid) {
				self.hide() 
			} else {
				var data = self.data['data'];
				if( !data || data.length <= 1 ) {
					var elem = self.$elem;
					addSelectedStyle.apply(elem);
					$(elem).data("gtips",data[0].value);
				} else {
					self.show();
				}
			}
		},
		calcPos: function() {

			var offset = this.$elem.offset(),
				elemWidth = this.$elem.width(),
				elemHeight = this.$elem.height(),
				tipsTop = offset.top + elemHeight + 2,
				tipsLeft = offset.left,
				tips = this.tipsElement,
				self = this,
				options = self.options;

			var bottom = tipsTop + tips.height();
			var dHeight = document.height;
			var arrow = tips.find('em');
			if( bottom >=  dHeight ) {
				tipsTop = offset.top - 8 - tips.height();
				arrow.css("top", tips.height() - 2 + "px")
					 .css("border-width", "6px 6px 0px 6px")
					 .css("border-bottom-color", "transparent")
					 .css("border-top-color","#2d2828");
			} else {
				arrow.css("top", "-6px")
					 .css("border-width", "0px 6px 6px 6px")
					 .css("border-bottom-color","#2d2828")
					 .css("border-top-color","transparent");
			}

			tips.css("top",tipsTop+"px")
				.css("left",tipsLeft+"px");
			if( options.fitWidth ) {
					tips.css("max-width", elemWidth + "px");
				}
			tipsLeft = Math.floor(tipsLeft + ( elemWidth  - tips.width() ) / 2);
			arrow.css("left",(tips.width() / 2 - 6) + "px");
		},
		createTips: function() {

			var options = this.options,
				id	= options.tipsElement.slice(1),
				tips = $('<div id='+id+'></div>'),
				$body = $('body');

			$body.prepend(tips);
			return id;
		},
		renderData: function() {

			var self = this,
				data = self.data,
				tips = self.tipsElement;
			if( !data ) {
				return;
			}

			data = data['data'];
			data = data.slice();
			var content = tips.find(".content");
			content.html('');
			var container = $('<ul></ul>');
			var length = data.length;
			for(var i = 0; i < length; i++ ) {
				var d = data[i].name;				
				var li = $('<li></li>');
				li.text(d);
				li.appendTo(container);
			}
			$(container).on('click','li',onItemSelected);
			content.append(container);
		}
	};

	var cache = {};

	$.fn.gtips = function(data,options) {
		if( isString(data) ) {
			var method = data,
				args = arguments,
				self = this;
			Array.prototype.shift.call(args);
			this.each(function(_,e){
				var key = e['gtips'],
					tips = cache[key]; 
				if( tips && tips[method] ) {
					tips[method].apply(tips,args);
				}
			});
			return this;
		} else {
			this.each(function(_,e){
				e['gtips'] = GUID;
				var key = e['gtips']
				cache[key] = new GTips(e,data,options);
			});
			return this;
		}
	}
})(window.jQuery || window.Zepto);