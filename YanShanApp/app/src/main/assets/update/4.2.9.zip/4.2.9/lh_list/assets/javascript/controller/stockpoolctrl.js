moneytree.directive('onFinishRenderFilters', function($timeout) {
    return {
        restrict: 'A',
        link: function(scope, element, attr) {
            if (scope.$last === true) {
                $timeout(function() {
                    scope.$emit('ngRepeatFinished');
                });
            }
        }
    };
});
moneytree.controller('StockPoolCtrl', function($scope, $route, $location) {
    var deviceReady = function() {
		Connector.execute({
			service: "DispatcherService",
			action: "changeSkin",
			arguments : ["selector_diagnosis/detail/index.html?type=1",""],
			success: function(data){if(data==2){$('head').append('<link href="assets/css/black.css" rel="stylesheet" type="text/css" />');}}
		});
        var handleSuccess = function(data) {
            $('.loading').hide();
			var dateNow = data['result']['date'];
			$('.titspa .left').text(dateNow);
            $scope.$apply(function() {
                $scope.stockList = [];
                 _.each(data['result']['data'], function(e, i) {
                    var _d = {
                        stockID: e['stockID'],
                        stockName: e['stockName'],
                        marketID: e['marketID'],
                        riseRange: e['riseRange'],
                        lastPrice: e['lastPrice'],
                        score: e['score'],
						colorLevel:(function(){
                            if(e['colorLevel']==1){
								  return "yellow"
							}
							else if(e['colorLevel']==2){
								  return "red"
							}
							else if(e['colorLevel']==3){
								  return "blue"
							}
							else if(e['colorLevel']==4){
								  return "green"
							}
							else if(e['colorLevel']==5){
								  return "gray"
							}
						 })(),
					   indexs: e['indexs']
                    };
                    $scope.stockList.push(_d);
					
                });
               
            });
			
        }
       var routePath = $scope.routePath;
        Connector.request({
            success: handleSuccess,
            error: function(message) {
		        var cordova = window.cordova;
                cordova.exec(null, null, "DispatcherService", "quit", []);
            },
            before: function() {
                $('.loading').css("display", "-webkit-box");
            },
            url:'GetLongHu',
            method: "post",
            data: {},
            useToken:false
        });
    
    };
   $scope.$on('$routeChangeSuccess', function() {
      $scope.routePath = $route.current.routePath;
  });

    Connector.deviceReady(deviceReady);
    Connector.load();
	 $scope.stockList = [];
	
    $('.content').on('click', 'ul li', function(e) {
		var viewMode = $scope.routePath;
		var target = $(e.currentTarget);
		var index = $("ul li").index(target);
		var stock = $scope.stockList[index];
		var sd =stock['stockName'];
		var da = "stockID=" + stock['stockID'] + "&marketID=" + stock['marketID'] + "&stockName=" + stock['stockName'];
		//location.href="seat.html?"+da;
		Connector.execute({
			service: "DispatcherService",
			action: "gotoStockLongHuDetail",
			arguments: ["lh_list/seat.html?"+da, sd]
		});
    });
	
	
	
	
  
});
