moneytree.directive('onFinishRenderFilters', function($timeout) {
    return {
        restrict: 'A',
        link: function(scope, element, attr) {
            if (scope.$last === true) {
                $timeout(function() {
                    scope.$emit('ngRepeatFinished');
                });
            }
        }
    };
});
moneytree.controller('StockPoolCtrl', function($scope, $route, $location) {
	
    var deviceReady = function() {
		Connector.execute({
			service: "DispatcherService",
			action: "changeSkin",
			arguments : ["selector_diagnosis/detail/index.html?type=1",""],
			success: function(data){if(data==2){$('head').append('<link href="assets/css/black.css" rel="stylesheet" type="text/css" />');}}
		});
        var handleSuccess = function(data) {
            $scope.$apply(function() {
                $scope.stockList = [];
                 _.each(data['result']['sdrNewsList'], function(e, i) {
                    var _d = {
                        title: e['title'],
                        //author: e['author'],
						author: (function(){
							if(e['author']=="早间第一眼"){
								return "one"
							}else if(e['author']=="直击两点半"){
								return "two"
							}else if(e['author']=="收盘必读"){
								return "three"
							}else{
								return "none"
							}	
						})(),
                        createTime: e['createTime'],
						timeS: (function(){
							//var savetime = window.sessionStorage.getItem('savetime');
							var date = new Date();
							Y = date.getFullYear() + '/';
							M = (date.getMonth()+1 < 10 ? '0'+(date.getMonth()+1) : date.getMonth()+1) + '/';
							D = (date.getDate() < 10 ? '0'+(date.getDate()) : date.getDate()) + ' ';
							var savetime =new Date(Y+M+D+'00:00:00');						
							if(e['issueTime'] > savetime.getTime()){
								return "on";
							}else{
								return false;
							}
						})(),
						issueTime: (function(){
							var date = new Date(e['issueTime']);
							M = (date.getMonth()+1 < 10 ? '0'+(date.getMonth()+1) : date.getMonth()+1) + '-';
							D = (date.getDate() < 10 ? '0'+(date.getDate()) : date.getDate()) + ' ';
							h = (date.getHours() < 10 ? '0'+(date.getHours()) : date.getHours()) + ':';
							m = (date.getMinutes() < 10 ? '0'+(date.getMinutes()) : date.getMinutes());
							return M+D+h+m;
						})(),
                        content: e['content'],
                        score: e['score'],
                    };
                    $scope.stockList.push(_d);
					
                });
               
            });
			var texts = $('.text');
			for(var k in texts){
				texts.eq(k).html(texts.eq(k).text());
			}
			var dates = new Date();
			var H = dates.getHours()*60;
			if(H>=720 && H<1020){
				var dom = $('.nav [type=two]');
				dom.addClass('on').siblings().removeClass('on');
				$('.page').hide();
				$('.two').parent().show();
			}else if(H>=1020){
				var dom = $('.nav [type=three]');
				dom.addClass('on').siblings().removeClass('on');
				$('.page').hide();
				$('.three').parent().show();
			}else{
				$('.page').hide();
				$('.one').parent().show();
			}
        }
       var routePath = $scope.routePath;
        Connector.request({
            success: handleSuccess,
            error: function(message) {
		        var cordova = window.cordova;
                cordova.exec(null, null, "DispatcherService", "quit", []);
            },
            before: function() {
                $('.loading').css("display", "-webkit-box");
            },
            url:'SDR',
            method: "post",
            data: {},
            useToken:true
        });
    
    };
   $scope.$on('$routeChangeSuccess', function() {
      $scope.routePath = $route.current.routePath;
	});

    Connector.deviceReady(deviceReady);
    Connector.load();
	$scope.stockList = [];
	
	
	$('.nav li').click(function(){
		$(this).addClass('on').siblings().removeClass('on');
		$('.page').hide();
		$('.'+$(this).attr('type')).parent().show();
	});
	
	
	$('html').swipeLeft(function(){
		var index = $('.nav .on').index();
		index++;
		if(index<3){
			$('.nav li').eq(index).addClass('on').siblings().removeClass('on');
			$('.page').hide();
			$('.'+$('.nav li').eq(index).attr('type')).parent().show();
		}
	});
	$('html').swipeRight(function(){
		var index = $('.nav .on').index();
		index--;
		if(index>=0){
			$('.nav li').eq(index).addClass('on').siblings().removeClass('on');
			$('.page').hide();
			$('.'+$('.nav li').eq(index).attr('type')).parent().show();
		}
	});
});
