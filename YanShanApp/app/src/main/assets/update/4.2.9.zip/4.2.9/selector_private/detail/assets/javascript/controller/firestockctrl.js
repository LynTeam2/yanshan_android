
moneytree.directive('onFinishRenderFilters', function ($timeout) {
    return {
        restrict: 'A',
        link: function(scope, element, attr) {
            if (scope.$last === true) {
                $timeout(function() {
                    scope.$emit('ngRepeatFinished');
                });
            }
        }
    };
});

moneytree.controller('FireStockCtrl', function($scope, $route, $location) {

    var query = window.location.search.slice();

    var deviceReady = function() {
		Connector.execute({
			service: "DispatcherService",
			action: "changeSkin",
			arguments : ["selector_diagnosis/detail/index.html?type=1",""],
			success: function(data){if(data==2){$('head').append('<link href="assets/css/black.css" rel="stylesheet" type="text/css" />');}}
		});
        var handleSuccess = function(data) {
            var resultID = data['code'];
            if (resultID != 200) {
                handleException(data['code'], data['requestID'], data['msg']);
                return;
            }

            $('.loading').hide();
            $scope.$apply(function() {
                $scope.stockList = [];
                $scope.trend        = data['result']['status']['trend'];
                $scope.topData      = data['result']['status']['topData'];
                $scope.pe           = data['result']['status']['pe'];
                $scope.score        = data['result']['status']['score'];
                $scope.mact         = data['result']['status']['mact'];
                $scope.checkNews    = data['result']['status']['checkNews'];
                $scope.checkHot     = data['result']['status']['checkHot'];
                $scope.checkOrg     = data['result']['status']['checkOrg'];
                $scope.checkPrivate = data['result']['status']['checkPrivate'];
                $scope.goldHole     = data['result']['status']['goldHole'];
                $scope.goldEye      = data['result']['status']['goldEye'];
                $scope.goldLine     = data['result']['status']['goldLine'];
                $scope.chipLock     = data['result']['status']['chipLock'];
                _.each(data['result']['data'], function(e, i) {
                    var _d = {
                        stockID: e['code'],
                        stockName: e['stockName'],
                        marketID: e['marketID'],
                        stockPrice: e['lastPrice'],
						riseValue: e['riseValue'],
						riseRangeString: e['riseRangeString'],
                        trend: e['trend'],
                        topData: e['topData'],
                        pe: e['pe'],
							isMyStock: e['isMyStock'],
							isd:(function(){
							return Number(e['isMyStock'])==1? "blockback":"redback"
						})(),
                       score:e['score'],
						scoreColor:(function(){
							  var oe=e['colorLevel'];
							  if(oe==3){return "color_blue";}
							  else if(oe==4){return "color_green"}
							  else if(oe==2){return "color_red"}
							  else if(oe==1){return "color_yellow"}
							  else if(oe==5){return "color_gray"}
						 })(),
                        mact: e['mact'],
                        checkNews: e['newsInfo'],
                        checkHot: e['hotInfo'],
                        checkOrg: e['orgInfo'],
                        checkPrivate: e['privateInfo'],
                        goldHole: e['goldHole'],
                        goldEye: e['goldEye'],
                        goldLine: e['goldLine'],
                        chipLock: e['chipLock'],
                        chipLockColor:(function(){
                            var chipLockIncrease = e['chipLock'].indexOf("-");
                            return chipLockIncrease >= 0 ? "down" : "up";
                        })(),
                        klineValue: (function() {
                            var stockValue = e['code'] + '_' + e['marketID'];
                            var da = data['result']['stockInfo'][stockValue];
                            var lineString = '';
                            for(var ii = da.length-1;ii >= 0; ii--){
                               lineString += da[ii]['date'] + ',' + da[ii]['open'] + ',' + da[ii]['high'] + ',' + da[ii]['low'] + ',' + da[ii]['close'] + ',' + da[ii]['volume'] + ',' + da[ii]['amount'] + ' '; 
                            }
                            lineString = lineString.substring(0, lineString.length - 1);
                            return lineString;
                        })()
                    };
                    $scope.stockList.push(_d);
                });
                $('#stock_list').removeClass('hidden');
            });
            if($scope.stockList.length<=0){
                $("#noresult").removeClass('hidden');
            }else{
                $('#stock_list').removeClass('hidden');
            }
        }


        var url = "CustomFireStock";

        query = query.substring(1, query.length);
        var data1 = query.split("&");
        var d = '{'
        $.each(data1, function(i, e) {

            e = e.split('=');
            var c = e[0];
            var n = e[1];
            d += '"' + c + '"' + ':' + n + ',';
        });
        d += '"from":"0","to":"50",'; 
        d = d.substring(0, d.length - 1);

        d += '}';
        d = JSON.parse(d);
        Connector.request({
            success: handleSuccess,
            error: function(message) {
                var cordova = window.cordova;
                cordova.exec(null, null, "DispatcherService", "quit", []);
            },
            before: function() {
                $('.loading').css("display", "-webkit-box");
            },
            url: url,
            method: "post",
            data: d,
            useToken: true
        });

        Connector.execute({
            service: "SuperbarService",
            action: "enableFunction",
            arguments: ["show_refresh"]
        });
    };

    Connector.deviceReady(deviceReady);
    Connector.load();

    $scope.$on('ngRepeatFinished', function (ngRepeatFinishedEvent) {
        var bg = document.getElementsByName('bgCanvas');
        for(var i = 0;i < bg.length;i++){
            var datakline = bg[i].getAttribute('klinedata');
            var draw = new initKLine(datakline);
            var bgc = bg[i];
            draw.drawBackground(bgc);
            draw.draw(bgc);
            bgc.style.width = "1280px";
            bgc.style.height = "800px";
        }
    });
    
     $scope.stockList = [];
    $('#stock_list').on('click', 'table', function(e) {
		 var viewMode = $scope.routePath;
         var target = $(e.currentTarget).parents('.content');
		 var index = $("div.content").index(target);
		 var stock = $scope.stockList[index];
		 if(stock['isMyStock']=="1"){
			Connector.execute({
                service: "DispatcherService",
                action: "viewStockDetail",
                arguments: [stock['stockID'], parseInt(stock['marketID'], 10), index, $scope.stockList]
            });
		 }
		else{
			Connector.request({
            success: function(){
				 $('.content').eq(index).find('.re_icon font').removeClass('redback').addClass('blockback');
				  stock['isMyStock']=1;
				},
            error: function(message) {
		        var cordova = window.cordova;
                cordova.exec(null, null, "DispatcherService", "quit", []);
            },
            url:'AddUserStock',
            method: "post",
            data:{
				 "list": 
					 {'marketID':stock['marketID'],
					 'stockID':stock['stockID'],
					 'sort':0
			     }
            },
           useToken: true
        });
     }
    });  
});
