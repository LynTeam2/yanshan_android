moneytree.directive('onFinishRenderFilters', function($timeout) {
    return {
        restrict: 'A',
        link: function(scope, element, attr) {
            if (scope.$last === true) {
                $timeout(function() {
                    scope.$emit('ngRepeatFinished');
                });
            }
        }
    };
});
moneytree.controller('StockPoolCtrl', function($scope, $route, $location) {
    var deviceReady = function() {
		Connector.execute({
			service: "DispatcherService",
			action: "changeSkin",
			arguments : ["selector_diagnosis/detail/index.html?type=1",""],
			success: function(data){if(data==2){$('head').append('<link href="assets/css/black.css" rel="stylesheet" type="text/css" />');}}
		});
        var handleSuccess = function(data) {
            console.log(data);
			$('.loading').hide();
			$('.yuxuanbox').show();
            $scope.$apply(function() {
               $scope.stockList = [];
			    _.each(data['result']['data'], function(e, i) {
					$('.yuxuanbox').hide();
                     var _d = {
                        stockID: e['stockID'],
                        stockName: e['name'],
                        marketID: e['marketID'],
                        close: e['close'],
						blockName: e['plateName'],
                        score: e['score'],
						rn:e['rn2'] ? e['rn2'] : "--",
						ppd:(function(){
									 var xiwei =[];
									 _.each(e['ppd'], function(q,i) { 
									 var _ds = {
								     	id:q['id']+1,
                                        pri:q['pri'],
                                        department:q['department'],
                                        enddate:q['enddate']
									 };
									xiwei.push(_ds);
								});	  
                               return xiwei;
						     })(),
						ppdsl:(function(){
							if(e['ppd']==""){
								return "--";
							}else{
								return e['ppd'][0]['pri'];
							};
						})(),
						psdsl:(function(){
							if(e['psd']==""){
								return "--";
							}else{
								return e['psd'][0]['priName'];
							};
						})(),
						psd:(function(){
									 var yangguang =[];
									 _.each(e['psd'], function(q,i) { 
									 var _ds = {
								     	id:q['id']+1,
                                        priName:q['priName'],
                                        manager:q['manager'],
                                        profitMon:q['profitMon'],
										rn:q['rn'],
                                        date:q['date'],
									 };
									yangguang.push(_ds);
									
								});	  
                               return yangguang;
						     })(),
                        sdl_1d3w: e['sdl_1d3w'],
                        ysdl_1d3w: e['ysdl_1d3w'],
                        plateRiseRange: e['plateRiseRange']*100,
					    accColor:(function(){
							return Number(e['plateRiseRange'])>0? "ftred":"ftgreen"
						})(),
						riseRangeString:e['riseRangeString'],
						riseRange:e['riseRange'],
						riseRangeColor:(function(){
                            var chipLockIncrease = e['riseRange'].indexOf("-");
                            return chipLockIncrease >=0 ? "ftblack" : "ftred";
                        })(),
                        isMyStock: e['isMyStock'],
							isd:(function(){
							return Number(e['isMyStock'])==1? "blockback":"redback"
						})(),
                        klineValue: (function() {
                            var stockValue = e['stockID'] + '_' + e['marketID'];
                            var da = data['result']['kline'][stockValue]['data'];
                            console.log(da);
                            da = da.substring(0, da.length - 1);
                            return da;
                        })()
                      };

                    $scope.stockList.push(_d);
                });
               
            });
		$('#listNum').text($('.content').length);
		if($('.content').length==0){$('.yuxuanbox').show();}else{$('.numbers').show();}
		
		if($('.listtit').children().eq(2).text()=='--'){
			$('.listtit').children().eq(1).hide();
		}
        }
       var routePath = $scope.routePath;
        Connector.request({
            success: handleSuccess,
            error: function(message) {
		        var cordova = window.cordova;
                cordova.exec(null, null, "DispatcherService", "quit", []);
            },
            before: function() {
                $('.loading').css("display", "-webkit-box");
            },
            url:'PrivateLongHu',
            method: "post",
            data:{},
            useToken:true
        });
 };
$scope.$on('$routeChangeSuccess', function() {
      $scope.routePath = $route.current.routePath;
 });

    Connector.deviceReady(deviceReady);
    Connector.load();

    $scope.$on('ngRepeatFinished', function(ngRepeatFinishedEvent) {
        var bg = document.getElementsByName('bgCanvas');
        for (var i = 0; i < bg.length; i++) {
            var datakline = bg[i].getAttribute('klinedata');
            var draw = new initKLine(datakline);
            var bgc = bg[i];
            draw.drawBackground(bgc);
            draw.draw(bgc);
            bgc.style.width = "1200px";
            bgc.style.height = "800px";
        }
    });
     $scope.stockList = [];
    $('#stock_list').on('click', '.advise', function(e) {
		 var viewMode = $scope.routePath;
         var target = $(e.currentTarget).parents('.content');
		 var index = $("div.content").index(target);
		 var stock = $scope.stockList[index];
		 if(stock['isMyStock']=="1"){
			Connector.execute({
                service: "DispatcherService",
                action: "viewStockDetail",
                arguments: [stock['stockID'], parseInt(stock['marketID'], 10), index, $scope.stockList]
            });
		 }
		else{
			Connector.request({
            success: function(){
				 $('.content').eq(index).find('.advise span').removeClass('redback').addClass('blockback');
				  stock['isMyStock']=1;
				  $('.showTit').show(1000).text('您已经添加成功!');
				  setInterval(function(){$('.showTit').hide();},3000)
				},
            error: function(message) {
		        var cordova = window.cordova;
                cordova.exec(null, null, "DispatcherService", "quit", []);
            },
            url:'AddUserStock',
            method: "post",
            data:{
				 "list": 
					 {'marketID':stock['marketID'],
					 'stockID':stock['stockID'],
					 'sort':0
			     }
            },
           useToken: true
        });
     }
    }); 
	$('#stock_list').on('click', '.data', function(e) {
		 var viewMode = $scope.routePath;
         var target = $(e.currentTarget).parents('.content');
		 var index = $("div.content").index(target);
		 var stock = $scope.stockList[index];
		 if(stock['isMyStock']=="1"){
			Connector.execute({
                service: "DispatcherService",
                action: "viewStockDetail",
                arguments: [stock['stockID'], parseInt(stock['marketID'], 10), index, $scope.stockList]
            });
		 }
		else{
			Connector.request({
            success: function(){
				 $('.content').eq(index).find('.advise span').removeClass('redback').addClass('blockback');
				  stock['isMyStock']=1;
				  $('.showTit').show(1000).text('您已经添加成功!');
				  setInterval(function(){$('.showTit').hide();},3000)
				},
            error: function(message) {
		        var cordova = window.cordova;
                cordova.exec(null, null, "DispatcherService", "quit", []);
            },
            url:'AddUserStock',
            method: "post",
            data:{
				 "list": 
					 {'marketID':stock['marketID'],
					 'stockID':stock['stockID'],
					 'sort':0
			     }
            },
           useToken: true
        });
     }
    }); 
	$('#stock_list').on('click', '.listtit', function(e) {
		if($(this).children().eq(2).text()=='--'){
			
		}else{
			 $(this).next().toggle();
			 $(this).children().eq(1).toggleClass('ata1 ata2')
		}
    }); 
	
});
