'use strict';
var moneytree = angular.module('moneytree', []).config(function ($routeProvider, $compileProvider) {

    $compileProvider.urlSanitizationWhitelist(/^\s*(file):/);

    $routeProvider
        .when('/diagnosis', {routePath: 'diagnosis'})
        .when('/pick', {routePath: 'pick'})
		.when('/fire', {routePath: 'fire'})
		.when('/org', {routePath: 'org'})
		.when('/private', {routePath: 'private'});
});