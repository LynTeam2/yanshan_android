
moneytree.directive('onFinishRenderFilters', function($timeout) {
    return {
        restrict: 'A',
        link: function(scope, element, attr) {
            if (scope.$last === true) {
                $timeout(function() {
                    scope.$emit('ngRepeatFinished');
                });
            }
        }
    };
});

moneytree.controller('DiagnosisStockCtrl', function($scope, $route, $location) {
    var query = window.location.search.slice();
    var deviceReady = function() {
		Connector.execute({
			service: "DispatcherService",
			action: "changeSkin",
			arguments : ["selector_diagnosis/detail/index.html?type=1",""],
			success: function(data){if(data==2){$('head').append('<link href="assets/css/black.css" rel="stylesheet" type="text/css" />');}}
		});
        var handleSuccess = function(data) {
            var resultID = data['code'];
            if (resultID != 200) {
                handleException(data['code'], data['requestID'], data['msg']);
                return;
            }

            $('.loading').hide();
            $scope.$apply(function() {
                $scope.stockList = [];
                $scope.macd                 = data['result']['status']['macd'];
                $scope.rsi                  = data['result']['status']['rsi'];
                $scope.kdj                  = data['result']['status']['kdj'];
                $scope.newHigh              = data['result']['status']['newHigh'];
                $scope.eps                  = data['result']['status']['eps'];
                $scope.pe                   = data['result']['status']['pe'];
                $scope.negotiableCapital    = data['result']['status']['negotiableCapital'];
                $scope.totalShareCapital    = data['result']['status']['totalShareCapital'];
                $scope.concept              = data['result']['status']['concept'];

                _.each(data['result']['data'], function(e, i) {
                    var _d = {
                        stockID: e['code'],
                        stockName: e['stockName'],
                        marketID: e['marketID'],
                        concept: e['concept'],
						isMyStock: e['isMyStock'],
						isd:(function(){
							return Number(e['isMyStock'])==1? "blockback":"redback"
						})(),
						riseRangeString:e['riseRangeString'],
						riseValue:e['riseValue'],
						score:e['score'],
						scoreColor:(function(){
							  var oe=e['colorLevel'];
							  if(oe==3){return "color_blue";}
							  else if(oe==4){return "color_green"}
							  else if(oe==2){return "color_red"}
							  else if(oe==1){return "color_yellow"}
							  else if(oe==5){return "color_gray"}
						 })(),
                        macd: (function(){
                            var val ='';
                            if (e['macd'] == 1) {
                                val = '绿柱翻红';
                            }else if(e['macd'] == -1){
                                val = '红柱翻绿';
                            }
                            return val;
                        })(),
                        rsi: (function(){
                            var val ='';
                            if (e['rsi'] == 1) {
                                val = '金叉';
                            }else if(e['rsi'] == -1){
                                val = '死叉';
                            }
                            return val;
                        })(),
                        kdj: (function(){
                            var val ='';
                            if (e['kdj'] == 1) {
                                val = '金叉';
                            }else if(e['kdj'] == -1){
                                val = '死叉';
                            }
                            return val;
                        })(),
                        newHigh: (function(){
                            var val = e['newHigh']+'日内';
                            return val;
                        })(),
                        eps: (function(){
                            return e['eps'];
                        })(),
                        pe: e['pe'],
                        negotiableCapital: (function(){
                            return e['negotiableCapitalString']+'亿股';
                        })(),
                        totalShareCapital: (function(){
                            return e['totalShareCapitalString']+'亿股';
                        })(),
                        stockPrice: e['lastPrice'],
                        klineValue: (function() {
                            var stockValue = e['code'] + '_' + e['marketID'];
                            var da = data['result']['stockInfo'][stockValue];
                            var lineString = '';
                            for(var ii = da.length-1;ii >= 0; ii--){
                               lineString += da[ii]['date'] + ',' + da[ii]['open'] + ',' + da[ii]['high'] + ',' + da[ii]['low'] + ',' + da[ii]['close'] + ',' + da[ii]['volume'] + ',' + da[ii]['amount'] + ' '; 
                            }
                            lineString = lineString.substring(0, lineString.length - 1);
                            return lineString;
                        })()
                    };
                    $scope.stockList.push(_d);
                });
            $('#stock_list').removeClass('hidden');
            });
                      if($scope.stockList.length<=0){
                            $("#noresult").removeClass('hidden');
                        }else{
                            $('#stock_list').removeClass('hidden');
                        }
        }

        var url = "CustomDiagnoseStock";
        query = query.substring(1, query.length);
        var data1 = query.split("&");
        var d = '{'
        $.each(data1, function(i, e) {
            e = e.split('=');
            var c = e[0];
            var n = e[1];
            d += '"' + c + '"' + ':' + n + ',';
        });
        d = d.substring(0, d.length - 1);
        d += '}';
        d = JSON.parse(d);
        Connector.request({
            success: handleSuccess,
            error: function(message) {
                var cordova = window.cordova;
                cordova.exec(null, null, "DispatcherService", "quit", []);
            },
            before: function() {
                $('.loading').css("display", "-webkit-box");
            },
            url: url,
            method: "post",
            data: d,
            useToken:true
        });
		
        Connector.execute({
            service: "SuperbarService",
            action: "enableFunction",
            arguments: ["show_refresh"]
        });
    };

    Connector.deviceReady(deviceReady);
    Connector.load();

    $scope.$on('ngRepeatFinished', function(ngRepeatFinishedEvent) {
        var bg = document.getElementsByName('bgCanvas');
        for (var i = 0; i < bg.length; i++) {
            var datakline = bg[i].getAttribute('klinedata');
            var draw = new initKLine(datakline);
            var bgc = bg[i];
            draw.drawBackground(bgc);
            draw.draw(bgc);
            bgc.style.width = "1200px";
            bgc.style.height = "800px";
        }
    });
  $scope.stockList = [];
    $('#stock_list').on('click', 'table', function(e) {
		 var viewMode = $scope.routePath;
         var target = $(e.currentTarget).parents('.content');
		 var index = $("div.content").index(target);
		 var stock = $scope.stockList[index];
		 if(stock['isMyStock']=="1"){
			Connector.execute({
                service: "DispatcherService",
                action: "viewStockDetail",
                arguments: [stock['stockID'], parseInt(stock['marketID'], 10), index, $scope.stockList]
            });
		 }
		else{
			Connector.request({
            success: function(){
				 $('.content').eq(index).find('.re_icon font').removeClass('redback').addClass('blockback');
				  stock['isMyStock']=1;
			},
            error: function(message) {
		        var cordova = window.cordova;
                cordova.exec(null, null, "DispatcherService", "quit", []);
            },
            url:'AddUserStock',
            method: "post",
            data:{
				 "list": 
					 {'marketID':stock['marketID'],
					 'stockID':stock['stockID'],
					 'sort':0
			     }
            },
            useToken: true
			});
		 }
    });  
});
