moneytree.directive('onFinishRenderFilters', function($timeout) {
    return {
        restrict: 'A',
        link: function(scope, element, attr) {
            if (scope.$last === true) {
                $timeout(function() {
                    scope.$emit('ngRepeatFinished');
                });
            }
        }
    };
});
moneytree.controller('SeatCtrl', function($scope, $route, $location) {
	var deviceReady = function() {
		Connector.execute({
			service: "DispatcherService",
			action: "changeSkin",
			arguments : ["selector_diagnosis/detail/index.html?type=1",""],
			success: function(data){if(data==2){$('head').append('<link href="assets/css/black.css" rel="stylesheet" type="text/css" />');}}
		});
		 var handleSuccesstop = function(data) {
		 console.log(data);	
		 $('.loading').hide();
	     $scope.$apply(function() {
			 var result = data['result'];
			 var isstock=window.sessionStorage.getItem('isStock');
			 if(isstock==1){
				   $('#zixuan').text('已添加').addClass('blockback');
				}
			  $scope.resuel={
				        isMyStock:result['isMyStock'],
					    deeBuy:(function() {
                        var ddepsBuyList = [];
					     _.each(result['list'], function(e,i) {
						   var _d = {
								date:e['date'],
								netAmount:e['netAmount'],
								netAmountString:e['netAmountString'],
								netAmountColor:(function(){
                                   var chipLockIncrease = e['netAmountString'].indexOf("-");
                                   return chipLockIncrease >=0 ? "ftgreen" : "ftred";
                                 })(),
                                debuy:(function(){
									 var buyList =[];
									 _.each(e['depsBuy'], function(q,i) {  
									 var _ds = {
								     	depName:q['depName'],
                                        buyAmount:q['buyAmount'],
                                        sellAmount:q['sellAmount'],
                                        buyAllTradeRate:q['buyAllTradeRate'],
                                        sellAllTradeRate:q['sellAllTradeRate']
									 };
									
									buyList.push(_ds);
									
								});	  
                               return buyList;
						
						     })(),
							 debuya:(function(){
									 var buyList =[];
									 _.each(e['depsSell'], function(q,i) {  
									 var _ds = {
								     	depName:q['depName'],
                                        buyAmount:q['buyAmount'],
                                        sellAmount:q['sellAmount'],
                                        buyAllTradeRate:q['buyAllTradeRate'],
                                        sellAllTradeRate:q['sellAllTradeRate']
									 };
									
									buyList.push(_ds);
									
								});	  
                               return buyList;
						
						     })(),
							 }; 
							
                            ddepsBuyList.push(_d);
						 });
                        return ddepsBuyList;
						
					    })(),
				   }; 
				  
			});
			$('.bivbox').eq(0).find('.titDe').toggleClass('art1 art2');;
	 	 };
	

		 Connector.request({
            success: handleSuccesstop,
            error: function(message) {
				var cordova = window.cordova;
                cordova.exec(null, null, "DispatcherService", "quit", []);
            },
            before: function() {
                $('.loading').css("display", "-webkit-box");
            },
            url:'GetLHDetail',
            method: "post",
		    data:{
				 'stockID':stockid,
				 'marketID':marketid,
				 'stockName':stockname
			},
            useToken:false
        });
		
		
} ;
var query = window.location.search.slice();
query = query.substring(1, query.length);
query = decodeURI(query);
var data1 = query.split("&");
var stockid = data1[0].split("=")[1];
var marketid = data1[1].split("=")[1];
var stockname = data1[2].split("=")[1];
 Connector.deviceReady(deviceReady);
 Connector.load();
   $('.zhuli').click(function(){
	   var da=window.location.search.slice();
	  window.location.href="seat.html?"+da;
	})
	
	$('.btn #chakan').on('click', function(e) {
		var index = 0;
		var stList = [{stockID: stockid ,stockName: stockname ,marketID: marketid}];
			Connector.execute({
                service: "DispatcherService",
                action: "viewStockDetail",
                arguments: [stockid, parseInt(marketid, 10), index, stList]
            });
	});
	
	$('.btn').on('click','#zixuan', function(e) {
		 var isstock=window.sessionStorage.getItem('isStock');
		if(isstock==0){
			Connector.request({
               success: function(data){
				       $('#zixuan').text('已添加').addClass('blockback');
				       $('.showTit').show(1000).text('您已经添加成功!');
						isstock=1;
						window.sessionStorage.setItem('isStock',isstock);
				        setInterval(function(){$('.showTit').hide();},3000);
					   
			},
            error: function(message) {
		        var cordova = window.cordova;
                cordova.exec(null, null, "DispatcherService", "quit", []);
            },
            url:'AddUserStock',
            method: "post",
            data: {
				 "list":{
					 'marketID':marketid,
			  	     'stockID':stockid,
				     'sort':0
					 }
				
				},
           useToken: true
        });
   }
   else{
	 return false;
	   
	}
});
});

