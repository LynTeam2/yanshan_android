(function(global,undefined){
    var handleException = function(resultID,requestID,msg) {
        cordova.exec(null,null,"ExceptionService","showException",[resultID,requestID,msg]);
    }
    if( typeof define !== "undefined" ) {
        define(function(){
           return handleException;
        });
    } else {
        global.handleException = handleException;
    }
})(this);

