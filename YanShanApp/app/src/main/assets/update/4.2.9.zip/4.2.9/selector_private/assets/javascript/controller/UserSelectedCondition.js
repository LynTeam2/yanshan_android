
moneytree.directive('onFinishRenderFilters', function($timeout) {
    return {
        restrict: 'A',
        link: function(scope, element, attr) {
            if (scope.$last === true) {
                $timeout(function() {
                    scope.$emit('ngRepeatFinished');
                });
            }
        }
    };
});

moneytree.controller('StockPoolCtrl', function($scope, $route, $location) {
    var deviceReady = function() {
		Connector.execute({
			service: "DispatcherService",
			action: "changeSkin",
			arguments : ["selector_diagnosis/detail/index.html?type=1",""],
			success: function(data){if(data==2){$('head').append('<link href="assets/css/black.css" rel="stylesheet" type="text/css" />');}}
		});
        var handleSuccess = function(data) {
            $scope.$apply(function() {
                $scope.stockList = [];
                _.each(data['result']['userSelectedConditionList'], function(e, i) {
					i++;
					if(i>8){return false;}
                    var _d = {
                        conditionName: e['conditionName'],
                        selectedCondition: e['selectedCondition'],
                        createTimeString: e['createTimeString'],
						id: e['id'],
                    };
                    $scope.stockList.push(_d);
                });
            });
        }

        Connector.request({
            success: handleSuccess,
            error: function(message) {
                var cordova = window.cordova;
                cordova.exec(null, null, "DispatcherService", "quit", []);
            },
            url: "getUserSelectedCondition",
            method: "post",
            data: {
				"type":4
			},
            useToken:true
        });
    };


    Connector.deviceReady(deviceReady);
    Connector.load();
	
  $scope.stockList = [];
    $('.save button').click(function() {
		var condition = "";	
		var name ="选股方案";
		if($(".save input").val()!=""){
			name=$(".save input").val();
		}
		var checkSuccess = function(data){
				if(data['result']['result']==0){
					$(".selected").each(function(){
						condition+=""+$(this).attr("data-key")+","+$(this).attr("data-gtips")+";";
					});
					if(condition!=""){
						Connector.request({
							success: function(){window.location.reload();},
							error: function(message) {
								var cordova = window.cordova;
								cordova.exec(null, null, "DispatcherService", "quit", []);
							},
							url: "insertUserSelectedCondition",
							method: "post",
							data: {
								"name": name,
								"condition":condition,
								"type":4
							},
							useToken:true
						});
					}else{
						$('.showTit').show(1000).text('至少选择一项选股条件!');
						setInterval(function(){$('.showTit').hide();},3000);
					}
				}else{
					$('.showTit').show(1000).text('名称已存在!');
				    setInterval(function(){$('.showTit').hide();},3000);
				}
			};
		Connector.request({
            success: checkSuccess,
            error: function(message) {
                var cordova = window.cordova;
                cordova.exec(null, null, "DispatcherService", "quit", []);
            },
            url: "checkUserSelectedCondition",
            method: "post",
            data: {
				"name": name,
				"condition":condition,
				"type":4
			},
            useToken:true
        });
    });
	$('.deletebox button').click(function() {
		var idnum = $('.fangan .on input').eq(1).val();
		Connector.request({
            success: function(){window.location.reload();},
            error: function(message) {
                var cordova = window.cordova;
                cordova.exec(null, null, "DispatcherService", "quit", []);
            },
            url: "deleteUserSelectedCondition",
            method: "post",
            data: {
				"id": idnum,
			},
            useToken:true
        });
    });
});