'use strict';
var moneytree = angular.module('moneytree', []); 