(function(global, undefined) {
        var bgc;
        var klc;

        var RED = "#f20733",
            GREEN = "#56b501",
            GRAY = "#9ba6c1",
            PURPLE = '#f04f84',
            YELLOW = '#ffa200',
            BLUE = '#23c2fe';
      CanvasRenderingContext2D.prototype.dashedLineTo = function (fromX, fromY, toX, toY, pattern) {
    	 if (typeof pattern === "undefined") {
    	     pattern = 2;
    	 }
    	 var dx = (toX - fromX);
    	 var dy = (toY - fromY);
    	 var distance = Math.floor(Math.sqrt(dx*dx + dy*dy));
    	 var dashlineInteveral = (pattern <= 0) ? distance : (distance/pattern);
    	 var deltay = (dy/distance) * pattern;
    	 var deltax = (dx/distance) * pattern;
    	  this.beginPath();
    	  for(var dl=0; dl< dashlineInteveral; dl++) {
			 this.lineWidth=2;
    	   if(dl%2) {
    	     this.lineTo(fromX + dl*deltax, fromY + dl*deltay);
    	   } else {    				 
    	     this.moveTo(fromX + dl*deltax, fromY + dl*deltay);    				
    	   }    			
    	 }
    	 this.stroke();
    }
        var _width = window.innerWidth*2;
        
    var _WIDTH = _width - 70, _X = 75, _SPACE = 20; 

    var kLine_y = 20, kLine_h = _WIDTH * 28 / 56+50, kLine_b = kLine_y + kLine_h;

    var fund_y = kLine_y + kLine_h + _SPACE, fund_h = 87, fund_b = fund_y + fund_h;

    var trend_y = fund_y + fund_h + _SPACE, trend_h = 84, trend_b = trend_y + trend_h;

    var maLine = [5, 10, 20];

    var splitLine1 = kLine_h / 5 + kLine_y,
        splitLine2 = kLine_h * 2 / 5 + kLine_y,
        splitLine3 = kLine_h * 3 / 5 + kLine_y,
        splitLine4 = kLine_h * 4 / 5 + kLine_y,
        splitLine5 = kLine_h + kLine_y,
        trendLine = trend_h / 2 + trend_y;

    var initKLine = function(data) {
        var datas = [],
            ks = data.split(" "),
            max = 0,
            min = 0xFFFFFFFF,
            maxVolume = 0;
        for (var i = 0; i < ks.length; i++) {
            var d = ks[i].split(",");
            var item = {
                date: d[0],
                open: d[1],
                high: d[2],
                low: d[3],
                close: d[4],
                volume: d[5],
                amount: d[6]
            };
            datas.push(item);
            max = Math.max(max, item.high);
            min = Math.min(min, item.low);
            maxVolume = Math.max(maxVolume, item.volume);
        }
        this.data = datas;
        this.length = this.data.length;
        this.max = max;
        this.min = min;
        this.maxVolume = maxVolume;
        this.deltaX = _WIDTH /this.length;
    };

    initKLine.prototype = {
        drawBackground: function(bgc) {
        	bgc.style.width = ""+$('.data').width()+"px";
        	bgc.style.height = ""+parseInt($('.data').width()/2)+"px";
        	$('.canvasDiv').height(parseInt($('.data').width()/1.85));
            var bg = bgc.getContext("2d");
            bg.beginPath();
            bg.fillStyle = "rgba(255, 255, 255, 0)";
            bg.translate(0.5, 0.5);
            bg.strokeStyle = "#9ba6c1";
            bg.fillRect(rounded(_X), rounded(kLine_y), rounded(_WIDTH), rounded(kLine_h));
            bg.dashedLineTo(rounded(_X), rounded(kLine_y),rounded(_WIDTH + _WIDTH/1.6),rounded(kLine_y));
		    bg.dashedLineTo(rounded(_X),rounded(splitLine5),rounded(_WIDTH + _WIDTH/1.6),rounded(splitLine5));
			
            bg.dashedLineTo(rounded(_X), rounded(splitLine1),rounded(_X + _WIDTH*1.6), rounded(splitLine1));
            bg.dashedLineTo(rounded(_X), rounded(splitLine2),rounded(_X + _WIDTH*1.6), rounded(splitLine2));
            bg.dashedLineTo(rounded(_X), rounded(splitLine3),rounded(_X + _WIDTH*1.6), rounded(splitLine3));
            bg.dashedLineTo(rounded(_X), rounded(splitLine4),rounded(_X + _WIDTH*1.6), rounded(splitLine4));
            bg.closePath();
            bg.fillStyle = GRAY;
            bg.textAlign = 'right';
            bg.font = "28px Arial";
            var dalta = ((this.max - this.min) / 5).toFixed(2);
            var ydatas = [(this.max).toFixed(2), (this.max - dalta).toFixed(2), (this.max - 2 * dalta).toFixed(2), (this.max - 3 * dalta).toFixed(2), (this.max - 4 * dalta).toFixed(2), (this.min).toFixed(2)];
            var ys = [kLine_y, splitLine1, splitLine2, splitLine3, splitLine4, splitLine5];
            for (var i = 0; i < ydatas.length; i++) {
                bg.fillText(ydatas[i], rounded(_X - 3), rounded(ys[i] + 3));
            }
        },
        draw: function(klc) {

            var kl = klc.getContext("2d");	
            kl.lineWidth = 1;

            var data = this.data,
                length = this.length,
                min = this.min,
                max = this.max,
                maxv = this.maxVolume,
                x = _X,
                color;

            for (var i = 0; i < length; i++) {
                var o = parseFloat(data[i].open);
                var h = parseFloat(data[i].high);
                var l = parseFloat(data[i].low);
                var c = parseFloat(data[i].close);
                var v = parseFloat(data[i].volume);
                var yTop = kLine_b - (h - min) * kLine_h / (max - min);
                var yOpen = kLine_b - (o - min) * kLine_h / (max - min);
                var yClose = kLine_b - (c - min) * kLine_h / (max - min);
                var yBottom = kLine_b - (l - min) * kLine_h / (max - min);

                var klHigh, klLow;

                if (c < o) {
                    color = GREEN;
                    klHigh = yOpen;
                    klLow = yClose;
                } else {
                    color = RED;
                    klHigh = yClose;
                    klLow = yOpen;
                }
                kl.strokeStyle = kl.fillStyle = color;

                var centerX = x+7 + 0.4 * this.deltaX*0.875;

                kl.beginPath();
                kl.moveTo(centerX, yTop);
                kl.lineTo(centerX, yBottom);
                kl.closePath();
                kl.stroke();
                kl.fillRect(x+7, klHigh, this.deltaX * 0.7, klLow - klHigh < 1 ? 1 : klLow - klHigh);


                x += this.deltaX*0.9;
            }
        },
        drawMAs: function() {
            var kl = klc.getContext("2d");
            kl.lineWidth = 1;
            var MAs = [{
                color: BLUE,
                daysCount: 5
            }, {
                color: YELLOW,
                daysCount: 10
            }, {
                color: PURPLE,
                daysCount: 20
            }];
            var me = this;
            for (var j = 0; j < MAs.length; j++) {
                var maHigh = 0,
                    maLow = 0;
                var MA = calcMAPrices(me.data, this.length, MAs[j].daysCount);
                var x = _X;
                var lastx = 0,
                    lasty = 0;
                kl.strokeStyle = MAs[j].color;
                kl.beginPath();

                for (var i = 0; i < MA.length; i++) {

                    var centerX = x + 0.4 * this.deltaX;
                    var y = kLine_b - (MA[i] * kLine_h) / me.max;

                    if (!MA[i]) {
                        x += this.deltaX;
                        continue;
                    }

                    if (i == MAs[j].daysCount) {
                        kl.moveTo(centerX, y);
                    } else {
                        kl.lineTo(centerX, y);
                    }

                    x += this.deltaX;
                }
                kl.stroke();
            }
        }
    }

    function calcMAPrices(data, count, daysCn) {

        var result = new Array();
        for (var i = 0; i < count; i++) {
            if (i < daysCn - 1) {
                result.push(false);
                continue;
            }
            var sum = 0;
            for (var k = i; k >= i - (daysCn - 1); k--) {
                sum += Number(data[k].close);
            }
            var val = (sum / daysCn).toFixed(2);
            result.push(val);
        }
        return result;
    }

    function rounded(somenum) {
        var rounded; 
        rounded = (0.5 + somenum) | 0;
        rounded = ~~ (0.5 + somenum);
        rounded = (0.5 + somenum) << 0;
        return rounded;
    }


    global.initKLine = initKLine;

})(window);
