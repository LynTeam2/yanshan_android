'use strict';
var moneytree = angular.module('moneytree', []).config(function ($routeProvider, $compileProvider) {

    $compileProvider.urlSanitizationWhitelist(/^\s*(file):/);

    $routeProvider
        .when('/goldGroup', {routePath: 'goldGroup'})
        .when('/diamondGroup', {routePath: 'diamondGroup'})
        .otherwise({redirectTo: '/goldGroup'});
});