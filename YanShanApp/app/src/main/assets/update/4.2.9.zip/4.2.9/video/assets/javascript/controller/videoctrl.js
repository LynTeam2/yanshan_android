
moneytree.controller('VideoCtrl', function($scope, $route, $location) {
   var deviceReady = function() {
	   Connector.execute({
			service: "DispatcherService",
			action: "changeSkin",
			arguments : ["selector_diagnosis/detail/index.html?type=1",""],
			success: function(data){if(data==2){$('head').append('<link href="assets/css/black.css" rel="stylesheet" type="text/css" />');}}
		});
        var handleSuccess = function(data) {
            var resultID = data['code'];
            if (resultID != SUCCESS_CODE) {
                handleException(data['code'], data['request_id'], data['msg']);
                return;
            }
           $('.loading').hide();
           $scope.$apply(function() {
			  $scope.videoList = [];
                _.each(data['result']['dayNews'], function(e, i) {
                    var _d = {
                     url: e['url'],
                     author: e['author'],
                     issueTime: e['issueTime'],
                     title: e['title'],
                     imgURL: e['imgURL'],
                     authorInfo: e['authorInfo'],
					 authorImg: e['authorImg'],
                     pageURL: e['pageURL']
                      
                    };

                    $scope.videoList.push(_d);
                });
                   
              });
        };

        var routePath = $scope.routePath;
        var url = '';
        if (routePath == 'diagnosis')
            url = 'DiagnoseVideo';
        else if (routePath == 'pick')
            url = 'ChooseVideo';
        else if (routePath == 'fire')
            url = 'FireVideo';
        else if (routePath == 'org')
            url = 'OrgVideo';
        else if (routePath == 'private')
            url = 'PrivateVideo';

       
        Connector.request({
            success: handleSuccess,
            error: function(message) {
                var cordova = window.cordova;
                cordova.exec(null, null, "DispatcherService", "quit", []);
            },
            before: function() {
                $('.loading').css("display", "-webkit-box");
            },
            url: url,
            method: "post",
            useToken: true
        });
    };

    $scope.$on('$routeChangeSuccess', function() {
        $scope.routePath = $route.current.routePath;
    });

    Connector.deviceReady(deviceReady);
    Connector.load();

    $('.buttonList').on('click', 'div.button', function(e) {
        var linkto = $(this).attr('linkto');
        $('.button').removeClass('select');
        $(this).toggleClass('select');
        $('.contentDiv').addClass('hide');
        $('.' + linkto).removeClass('hide');
    });
    $('.content').on('click', 'div.video', function(e) {
        $('.video').removeClass('select');
        $(this).addClass('select');
        var title = $(this).children('.text').children('p.newsTitle').text(),
            issueTime = $(this).children('.text').children('p.time').text(),
            imgURL = $(this).children('img').attr('imgURL'),
            url = $(this).children('img').attr('videoURL'),
            author = $(this).children('img').attr('author'),
            authorInfo = $(this).children('img').attr('authorInfo'),
            authorImg = $(this).children('img').attr('src');
        $('#video').attr({
            src: url,
            poster: imgURL
        });
        $('#authorImg').attr('src', authorImg);
        $('#title').text(title);
        $('#issueTime').text(issueTime);
        $('#author').text(author);
        $('#authorInfo').text(authorInfo);
    });
});
