
moneytree.directive('onFinishRenderFilters', function ($timeout) {
    return {
        restrict: 'A',
        link: function(scope, element, attr) {
            if (scope.$last === true) {
                $timeout(function() {
                    scope.$emit('ngRepeatFinished');
                });
            }
        }
    };
});

moneytree.controller('PickStockCtrl', function($scope, $route, $location) {

    var query = window.location.search.slice();

    var deviceReady = function() {
		Connector.execute({
			service: "DispatcherService",
			action: "changeSkin",
			arguments : ["education_base/detail/index.html?type=1",""],
			success: function(data){if(data==2){$('head').append('<link href="assets/css/black.css" rel="stylesheet" type="text/css" />');}}
		});
        var handleSuccess = function(data) {
            var resultID = data['code'];
            if (resultID != 200) {
                handleException(data['code'], data['requestID'], data['msg']);
                return;
            }

            $('.loading').hide();

            $scope.$apply(function() {
                $scope.stockList = [];

                $scope.goldHole     = data['result']['status']['goldHole'];
                $scope.goldEye      = data['result']['status']['goldEye'];
				$scope.goldLine     = data['result']['status']['goldLine'];
				
				var keynum = 0;
				if(data['result']['status']['goldHole']){keynum++;}
				if(data['result']['status']['goldEye']){keynum++;}
				if(data['result']['status']['goldLine']){keynum++;}
				$scope.keynum = keynum;
				
                _.each(data['result']['data'], function(e, i) {
                    var _d = {
                        stockID: e['code'],
                        stockName: e['stockName'],
                        marketID: e['marketID'],
                        trend: e['trend'],
                        topData: e['topData'],
                        pe: e['pe'],
						stockPrice:e['lastPrice'],
						riseValue:e['riseValue'],
						riseRangeString:e['riseRangeString'],
                        score: e['score'],
                        mact: e['mact'],
							isMyStock: e['isMyStock'],
							isd:(function(){
							return Number(e['isMyStock'])==1? "blockback":"redback"
						})(),
						scoreColor:(function(){
						   var oe=e['colorLevel'];
							  if(oe==3){return "color_blue";}
							  else if(oe==4){return "color_green"}
							  else if(oe==2){return "color_red"}
							  else if(oe==1){return "color_yellow"}
							  else if(oe==5){return "color_gray"}
						})(),
                        checkNews: e['newsInfo'],
                        checkHot: e['hotInfo'],
                        goldHole: e['goldHole'],
						goldLine: e['goldLine'],
						
						backstock:(function(){
							var isMySt=e['isMyStock'];
							if(isMySt==0)
							{return "assets/images/add.png";}
							else {return "assets/images/true.png"}
						})(),
                        goldEye: e['goldEye'],
                        klineValue: (function() {
                            var stockValue = e['code'] + '_' + e['marketID'];
                            var da = data['result']['stockInfo'][stockValue];
                            var lineString = '';
                            for(var ii = da.length-1;ii >= 0; ii--){
                               lineString += da[ii]['date'] + ',' + da[ii]['open'] + ',' + da[ii]['high'] + ',' + da[ii]['low'] + ',' + da[ii]['close'] + ',' + da[ii]['volume'] + ',' + da[ii]['amount'] + ' '; 
                            }
                            lineString = lineString.substring(0, lineString.length - 1);
                            return lineString;
                        })()
                    };
                    $scope.stockList.push(_d);
                });
            $('#stock_list').removeClass('hidden');
            });
						if($scope.stockList.length<=0){
                            $("#noresult").removeClass('hidden');
							$('#submit').hide();
                        }else{
                            $('#stock_list').removeClass('hidden');
                        }
        }


        var url = "CustomSelectStock";

        query = query.substring(1, query.length);
        var data1 = query.split("&");
        var d = '{'
        $.each(data1, function(i, e) {
            e = e.split('=');
            var c = e[0];
            var n = e[1];
			if(c!='xlcdata'){
				d += '"' + c + '"' + ':' + n + ',';
			}
        });
        d = d.substring(0, d.length - 1);
        d += '}';
        d = JSON.parse(d);
        Connector.request({
            success: handleSuccess,
            error: function(message) {
                var cordova = window.cordova;
                cordova.exec(null, null, "DispatcherService", "quit", []);
            },
            before: function() {
                $('.loading').css("display", "-webkit-box");
            },
            url: url,
            method: "post",
            data: d,
            useToken: true
        });

    };



    Connector.deviceReady(deviceReady);
    Connector.load();

    $scope.$on('ngRepeatFinished', function (ngRepeatFinishedEvent) {
        var bg = document.getElementsByName('bgCanvas');
       
        for(var i = 0;i < bg.length;i++){
            var datakline = bg[i].getAttribute('klinedata');
            var draw = new initKLine(datakline);
            var bgc = bg[i];
            draw.drawBackground(bgc);
            draw.draw(bgc);
            bgc.style.width = "1280px";
            bgc.style.height = "800px";
        }
    });

   $scope.stockList = [];
    $('#stock_list').on('click', 'table .re_name,table .re_num,table .re_id,table .re_rat', function(e) {
		 var viewMode = $scope.routePath;
         var target = $(e.currentTarget).parents('.content');
		 var index = $("div.content").index(target);
		 var stock = $scope.stockList[index];
		 Connector.execute({
			service: "DispatcherService",
			action: "viewStockDetail",
			arguments: [stock['stockID'], parseInt(stock['marketID'], 10), index, $scope.stockList]
		});
    });  
	
	$('#stock_list').on('click', 'table .re_icon', function(e) {
		 var viewMode = $scope.routePath;
         var target = $(e.currentTarget).parents('.content');
		 var index = $("div.content").index(target);
		 var stock = $scope.stockList[index];
		 $(this).find('font').toggleClass('redback blockback');
    });  
	
	$('#stock_list').on('click','.conditions .contain-btn',function(){
		$(this).toggleClass('selected');
	});
	
	var hpps='https://demo-api.topxlc.com';
	var selectdata=[{key:"goldHole",name:"黄金坑",data:[{name:"当前",value:1},{name:"10天内",value:10},{name:"20天内",value:20}]},
			  {key:"goldEye",name:"黄金眼",data:[{name:"黄:10日内",value:10},{name:"黄:20日内",value:20},{name:"绿:10日内",value:-10},{name:"绿:20日内",value:-20}]},
			  {key:"goldLine",name:"黄金线",data:[{name:"线上:5日",value:5},{name:"线上:10日",value:10},{name:"线下:5日",value:-5},{name:"线下:10日",value:-10}]}];
	//var hpps='https://unify-api.topxlc.com';
	$('#submit').click(function(){
		var user_id;
		var author_user_id;
		var content_type;
		var content_id;
		var conditions = '';
		var data2 = window.location.search.slice().substring(1, window.location.search.slice().length).split("&");
		$.each(data2, function(i, e) {
            e = e.split('=');
            var c = e[0];
            var n = e[1];
			if(c!='xlcdata'){
				for(var j in selectdata){
					if(selectdata[j].key==c){
						conditions += selectdata[j].name+'：';
						for(var k in selectdata[j].data){
							if(selectdata[j].data[k].value==n){
								conditions+= selectdata[j].data[k].name+'，';
							}
						}
					}
				}
			}else{
				n= e[1].split(';');
				user_id = parseInt(n[0]);
				author_user_id = parseInt(n[1]);
				content_type = parseInt(n[2]);
				content_id = parseInt(n[3]);
			}
        });
		if(conditions.substring(conditions.length-1)=='，'){
				conditions = conditions.substring(0,conditions.length-1);
			}
		var tage = 0;
		$('#stock_list .blockback').each(function(){
			var dom = $(this).parents('.content');
			var index = $("div.content").index(dom);
			var stock = $scope.stockList[index];
			var indexes = '';
			dom.find('.contain-btn.selected').each(function(){
				indexes += $(this).find('.item-name').text()+'、';
			});
			if(indexes.substring(indexes.length-1)=='、'){
				indexes = indexes.substring(0,indexes.length-1);
			}
			var base = hpps + '/user/submit_homework.uds';
			
			axios.post(base,{
				"action": "/user/submit_homework",
				"params":{
					"user_id": user_id,
					"author_user_id": author_user_id,
					"content_type": content_type,
					"content_id": content_id,
					"stock_code":stock.stockID+"",
					"market_type":(parseInt(stock.marketID)+1),
					"stock_name":stock.stockName,
					"gold_eye":stock.goldEye+"天",
					"gold_hole":stock.goldHole+"天",
					"gold_line":stock.goldLine+"天",
					"indexes":indexes,
					"conditions":conditions
				}
			}, {
				headers: {
					'Content-Type': 'application/json'
				}
			})
			.then(function(data) {
				if(data.data.code==8200 ){
					tage++;
					if(tage==1){
						alert('您的作业已经提交!')
					}
				}
			})
		});
	});
});
