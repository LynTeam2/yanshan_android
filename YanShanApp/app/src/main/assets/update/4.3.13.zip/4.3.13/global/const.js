var SERVER_ADDRESS = "http://115.238.35.61:8280";
var DEBUG_ADDRESS = "http://web.niniu.so:8100";
var SERVICE_PATH = SERVER_ADDRESS + "/mintcode/webservices";
var DEBUG = true;
var SUCCESS_CODE = 200;
(function(){
     if (DEBUG) {
         SERVER_ADDRESS = DEBUG_ADDRESS;
         SERVICE_PATH = SERVER_ADDRESS + "/mintcode/webservices";
     }
})();
