moneytree.directive('onFinishRenderFilters', function($timeout) {
    return {
        restrict: 'A',
        link: function(scope, element, attr) {
            if (scope.$last === true) {
                $timeout(function() {
                    scope.$emit('ngRepeatFinished');
                });
            }
        }
    };
});

moneytree.controller('StockPoolCtrl', function($scope, $route, $location) {

    var deviceReady = function() {
		Connector.execute({
			service: "DispatcherService",
			action: "changeSkin",
			arguments : ["selector_diagnosis/detail/index.html?type=1",""],
			success: function(data){if(data==2){$('head').append('<link href="assets/css/black.css" rel="stylesheet" type="text/css" />');}}
		});
        var handleSuccess = function(data) {
            console.log(data);
            var resultID = data['code'];
            if (resultID != SUCCESS_CODE || !data['result']['data']) {
                handleException(data['code'], data['requestID'], data['msg']);
                return;
            }
            $('.loading').hide();
			$('.yuxuanbox').show();
            $scope.$apply(function() {
                $scope.stockList = [];
				
                _.each(data['result']['data'], function(e, i) {
					$('.yuxuanbox').hide();
                    var _d = {
                        stockID: e['code'],
                        stockName: e['stockName'],
                        marketID: e['marketID'],
                        createDate: e['createTimeDate'],
                        type: e['type'],
						rn:e['rn2'] ? e['rn2'] : "--",
						isMyStock: e['isMyStock'],
							isd:(function(){
							return Number(e['isMyStock'])==1? "blockback":"redback"
						})(),
						lastPrice: e['lastPrice'],
						riseRangeString: e['riseRangeString'],
						accumulateIncreaseString: e['accumulateIncreaseString'],
						accColor:(function(){
							  var ore= e['accumulateIncreaseString'].indexOf('-');
							 return ore>=0?"ftgreen":"ftred"
						})(),
                        score: e['score'],
                        scoreColor: (function() {
                            var score = e['score'];
                            return score >= 60 ? "up" : "down";
                        })(),
                        report: e['report'],
                        reportURL: (function() {
                            return ''
                        })(),
                        reportNew: e['reportNew'],
                        receiptsPerTenthousand: e['receiptsPerTenthousand'],
                        videoUrl: e['videoUrl'],
                        stockPrice: (function() {
                            return e['lastPrice'];
                        })(),
                        checkNews: e['newsInfo'],
                        checkHot: e['hotInfo'],
                        createTimeDate: e['createTimeDate'],
                        goldHole: (function() {
                            var goldHoleValue = '';
                            if (e['goldHole'] == 1) {
                                goldHoleValue = '当前';
                            } else {
                                goldHoleValue = e['goldHole'] + '天';
                            }
                           
                            return goldHoleValue;
                        })(),
                        goldEye: e['goldEye'],
                        riseRange: e['riseRangeString'],
                        chipLock: (function() {
                            return e['chipLock'];
                        })(),
                        chipLockColor:(function(){
                            var chipLockIncrease = e['chipLock'].indexOf("-");
                            return chipLockIncrease >= 0 ? "ftgreen" : "ftred";
                        })(),
                        riseRange:e['riseRange'],
                        riseRangecolor: (function() {
                            var riseRange = e['riseRange'].indexOf("-");
                            return riseRange >= 0 ? "ftgreen" : "ftred";
                        })(),
                        accumulateIncrease: e['accumulateIncreaseString'],
                        accumulateIncreaseColor: (function() {
                            var accumulateIncrease = e['accumulateIncrease'];
                            return accumulateIncrease >= 0 ? "up" : "down";
                        })(),
                        klineValue: (function() {
                            var stockValue = e['code'] + '_' + e['marketID'];
                            var da = data['result']['kline'][stockValue]['data'];
                            console.log(da);
                            da = da.substring(0, da.length - 1);
                            return da;
                        })()
                    };
                  
                    $scope.stockList.push(_d);
					
                });
               
            });
			$('#listNum').text($('.content').length);
			$('.numbers').show();
        }

        var routePath = $scope.routePath;
        var url = '';
        if (routePath == 'goldGroup')
            url = 'GetBuffetGroup';
        else if (routePath == 'diamondGroup')
            url = 'GetGerogeGroup';
        Connector.request({
            success: handleSuccess,
            error: function(message) {
                var cordova = window.cordova;
                cordova.exec(null, null, "DispatcherService", "quit", []);
            },
            before: function() {
                $('.loading').css("display", "-webkit-box");
            },
            url: url,
            method: "post",
            data: {},
            useToken:true
        });

       
    };

    $scope.$on('$routeChangeSuccess', function() {
        $scope.routePath = $route.current.routePath;
    });

    Connector.deviceReady(deviceReady);
    Connector.load();

    $scope.$on('ngRepeatFinished', function(ngRepeatFinishedEvent) {
        var bg = document.getElementsByName('bgCanvas');
        for (var i = 0; i < bg.length; i++) {
            var datakline = bg[i].getAttribute('klinedata');
            var draw = new initKLine(datakline);
            var bgc = bg[i];
            draw.drawBackground(bgc);
            draw.draw(bgc);
            bgc.style.width = "1200px";
            bgc.style.height = "800px";
        }
    });

     $scope.stockList = [];
    $('#stock_list').on('click', 'div.content', function(e) {
		 var viewMode = $scope.routePath;
         var target = $(e.currentTarget);
		 var index = $("div.content").index(target);
		 var stock = $scope.stockList[index];
		 if(stock['isMyStock']=="1"){
			Connector.execute({
                service: "DispatcherService",
                action: "viewStockDetail",
                arguments: [stock['stockID'], parseInt(stock['marketID'], 10), index, $scope.stockList]
            });
		 }
		else{
			Connector.request({
            success: function(){
				 $('.content').eq(index).find('.advise span').removeClass('redback').addClass('blockback');
				  stock['isMyStock']=1;
				  $('.showTit').show(1000).text('您已经添加成功!');
				  setInterval(function(){$('.showTit').hide();},3000)
				},
            error: function(message) {
		        var cordova = window.cordova;
                cordova.exec(null, null, "DispatcherService", "quit", []);
            },
            url:'AddUserStock',
            method: "post",
            data:{
				 "list": 
					 {'marketID':stock['marketID'],
					 'stockID':stock['stockID'],
					 'sort':0
			     }
            },
           useToken: true
        });
     }
    });  
});
