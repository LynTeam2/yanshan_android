moneytree.directive('onFinishRenderFilters', function($timeout) {
    return {
        restrict: 'A',
        link: function(scope, element, attr) {
            if (scope.$last === true) {
                $timeout(function() {
                    scope.$emit('ngRepeatFinished');
                });
            }
        }
    };
});

moneytree.controller('OrgStockCtrl', function($scope, $route, $location) {

    var query = window.location.search.slice();
    var deviceReady = function() {
		Connector.execute({
			service: "DispatcherService",
			action: "changeSkin",
			arguments : ["selector_diagnosis/detail/index.html?type=1",""],
			success: function(data){if(data==2){$('head').append('<link href="assets/css/black.css" rel="stylesheet" type="text/css" />');}}
		});
        var handleSuccess = function(data) {
            var resultID = data['code'];
            if (!(data['result']['orgData']) && !(data['result']['selectData'])) {
                $("#noresult").removeClass('hidden');
                return;
            } else {
              
                var kline;
                var stock_kline = '';
                $scope.orgData = "hidden";
                $scope.selectData = "hidden";
                if ((data['result']['orgData']) && !(data['result']['selectData'])) {
                    $scope.orgData = "nohidden";
                    for (var i = 0; i < data['result']['orgData'].length; i++) {
                        stock_kline += data['result']['orgData'][i]['code'] + "." + data['result']['orgData'][i]['marketID'] + ",";
                    }
                } else if (!(data['result']['orgData']) && (data['result']['selectData'])) {
                    $scope.selectData = "nohidden";
                    for (var i = 0; i < data['result']['selectData'].length; i++) {
                        stock_kline += data['result']['selectData'][i]['stockID'] + "." + data['result']['selectData'][i]['marketID'] + ",";
                    }
                }
                stock_kline = stock_kline.substring(0, stock_kline.length - 1);
                query = query.substring(0, query.length);
                var data2 = query.split("&");
                var d1 = '{';
                $.each(data2, function(i, e) {
                    e = e.split('=');
                    var c = e[0];
                    var n = e[1];
                    d1 += '"' + c + '"' + ':"' + n + '",';

                });
                d1 = d1.substring(1, d1.length - 1);
                //alert(d1);
                var d = '{"data":"' + stock_kline + '","klineRerightType":"Kline","type":"KLINE_DAY","klineCount":"20",'+ d1 +'}';
                //alert(d);
                d = JSON.parse(d);
                Connector.request({
                    success: function(klinedata) {
                        kline = klinedata;
                        $scope.$apply(function() {
                            $scope.stockList = [];

                            if ((data['result']['orgData']) && !(data['result']['selectData'])) {

                                _.each(data['result']['orgData'], function(e, i) {
                                    var _d = {
                                        stockID: e['code'],
                                        stockName: e['stockName'],
                                        marketID: e['marketID'],
                                        stockPrice: e['latestPrice'],
										riseValue:e['riseValue'],
										riseRangeString:e['riseRangeString'],
										isMyStock: e['isMyStock'],
							isd:(function(){
							return Number(e['isMyStock'])==1? "blockback":"redback"
						})(),
                                        riseRange: e['changeRate'] >= 0 ? "+" + (e['changeRate'] * 100).toFixed(2) : (e['changeRate'] * 100).toFixed(2),
                                        riseRangeColor: e['changeRate'] >= 0 ? "up" : "down",
										scoreColor:(function(){
							               var oe=e['colorLevel'];
							               if(oe==3){return "color_blue";}
							               else if(oe==4){return "color_green"}
							               else if(oe==2){return "color_red"}
							               else if(oe==1){return "color_yellow"}
										   else if(oe==5){return "color_gray"}
						                 })(),
                                        org: (function() {
                                            return encodeURI(JSON.stringify(e));
                                        })(),
                                        klineValue: (function() {
                                            var da = kline['result']['detailData'][i]['klines']['data'];
                                            var lineString = '';
                                            for (var ii = 0; ii <= da.length - 1; ii++) {
                                                lineString += da[ii]['date'] + ',' + da[ii]['open'] + ',' + da[ii]['high'] + ',' + da[ii]['low'] + ',' + da[ii]['price'] + ',' + da[ii]['volume'] + ',' + 'amount' + ' ';
                                            }
                                            lineString = lineString.substring(0, lineString.length - 1);
                                            return lineString;
                                        })()
                                    };
                                    $scope.stockList.push(_d);
                                });

                            } else if (!(data['result']['orgData']) && (data['result']['selectData'])) {
                                $scope.trend = isChecked('trend');
                                $scope.topData = isChecked('topData');
                                $scope.pe = isChecked('pe');
                                $scope.score = isChecked('score');
                                $scope.mact = isChecked('mact');
                                $scope.checkNews = isChecked('checkNews');
                                $scope.checkHot = isChecked('checkHot');
                                $scope.checkOrg = isChecked('checkOrg');
                                $scope.checkPrivate = isChecked('checkPrivate');
                                $scope.goldHole = isChecked('goldHole');
                                $scope.goldEye = isChecked('goldEye');
                                $scope.goldLine = isChecked('goldLine');
                                $scope.chipLock = isChecked('chipLock');

                                _.each(data['result']['selectData'], function(e, i) {
                                    var _d = {
                                        stockID: e['stockID'],
                                        stockName: e['stockName'],
                                        marketID: e['marketID'],
										riseValue:e['riseValue'],
										riseRangeString:e['riseRangeString'],
                                        stockPrice: e['lastPrice'],
											isMyStock: e['isMyStock'],
							isd:(function(){
							return Number(e['isMyStock'])==1? "blockback":"redback"
						})(),
                                        riseRange: e['riseRange'] >= 0 ? "+" + e['riseRange'] : e['riseRange'],
                                        riseRangeColor: e['riseRange'] >= 0 ? "up" : "down",
                                        trend: e['trend'],
                                        topData: e['topData'],
                                        pe: e['pe'],
                                        score: e['score'],
										scoreColor:(function(){
										 var oe=e['colorLevel'];
										  if(oe==3){return "color_green";}
										  else if(oe==4){return "color_blue"}
										  else if(oe==2){return "color_red"}
										  else if(oe==1){return "color_yellow"}
										  else if(oe==5){return "color_gray"}
						                   })(),
                                        mact: e['mact'],
                                        checkNews: e['newsInfo'],
                                        checkHot: e['hotInfo'],
                                        checkOrg: e['orgInfo'],
                                        checkPrivate: e['privateInfo'],
                                        goldHole: e['goldHole'],
                                        goldEye: e['goldEye'],
                                        goldLine: e['goldLine'],
                                        chipLock:(function(){
                                            var chipLock = kline['result']['detailData'][i]['klines']['chipLock'];
                                            return chipLock;
                                        })(),
                                        chipLockColor:(function(){
                                            var chipLockIncrease = kline['result']['detailData'][i]['klines']['chipLock'].indexOf("-");
                                            return chipLockIncrease >= 0 ? "down" : "up";
                                        })(),
                                        klineValue: (function() {
                                            var da = kline['result']['detailData'][i]['klines']['data'];
                                            var lineString = '';
                                            for (var ii = 0; ii <= da.length - 1; ii++) {
                                                lineString += da[ii]['date'] + ',' + da[ii]['open'] + ',' + da[ii]['high'] + ',' + da[ii]['low'] + ',' + da[ii]['price'] + ',' + da[ii]['volume'] + ',' + 'amount' + ' ';
                                            }
                                            lineString = lineString.substring(0, lineString.length - 1);
                                            return lineString;

                                        })()
                                    };
                                        $scope.stockList.push(_d);
                                });
                            }
							 $('.loading').hide();
                            $('#stock_list').removeClass('hidden');
                        });
                        if($scope.stockList.length<=0){
                            $("#noresult").removeClass('hidden');
                        }else{
                            $('#stock_list').removeClass('hidden');
                        }
                        $('.loading').hide();
                    },
                    error: function(message) {
                        var cordova = window.cordova;
                        cordova.exec(null, null, "DispatcherService", "quit", []);
                    },
                    url: "StockInfo",
                    method: "post",
                    data: d,
                    useToken: true
                });


            }


        }

        var url = "OrgCustom";
        query = query.substring(1, query.length);
        var data1 = query.split("&");
        var d = '{'
        $.each(data1, function(i, e) {
            e = e.split('=');
            var c = e[0];
            var n = e[1];
            d += '"' + c + '"' + ':' + n + ',';

        });
        d += '"from":"0","to":"30",';
        d = d.substring(0, d.length - 1);

        d += '}';
        d = JSON.parse(d);

        function isChecked(key) {
            return query.indexOf(key) >= 0 ? "nohidden" : "hidden";
        }
        Connector.request({
            success: handleSuccess,
            error: function(message) {
                var cordova = window.cordova;
                cordova.exec(null, null, "DispatcherService", "quit", []);
            },
            before: function() {
                $('.loading').css("display", "-webkit-box");
            },
            url: url,
            method: "post",
            data: d,
            useToken: true
        });
    };

    Connector.deviceReady(deviceReady);
    Connector.load();

    $scope.$on('ngRepeatFinished', function(ngRepeatFinishedEvent) {
        var bg = document.getElementsByName('bgCanvas');
        for (var i = 0; i < bg.length; i++) {
            var datakline = bg[i].getAttribute('klinedata');
            var draw = new initKLine(datakline);
            var bgc = bg[i];
            draw.drawBackground(bgc);
            draw.draw(bgc);
            bgc.style.width = "1280px";
            bgc.style.height = "800px";
        }
    });
  $scope.stockList = [];
   $('#stock_list').on('click', 'table', function(e) {
		 var viewMode = $scope.routePath;
         var target = $(e.currentTarget).parents('.content');
		 var index = $("div.content").index(target);
		 var stock = $scope.stockList[index];
		 if(stock['isMyStock']=="1"){
			Connector.execute({
                service: "DispatcherService",
                action: "viewStockDetail",
                arguments: [stock['stockID'], parseInt(stock['marketID'], 10), index, $scope.stockList]
            });
		 }
		else{
			Connector.request({
            success: function(){
				 $('.content').eq(index).find('.re_icon font').removeClass('redback').addClass('blockback');
				  stock['isMyStock']=1;
				},
            error: function(message) {
		        var cordova = window.cordova;
                cordova.exec(null, null, "DispatcherService", "quit", []);
            },
            url:'AddUserStock',
            method: "post",
            data:{
				 "list": 
					 {'marketID':stock['marketID'],
					 'stockID':stock['stockID'],
					 'sort':0
			     }
            },
           useToken: true
        });
     }
    });  
	
	$('#stock_list').on('click', '.orgDetail', function(e) {
        $scope.$apply(function() {
            var target = $(e.currentTarget).parents('.content');
            var index = $("div.content").index(target);
            var stock = $scope.stockList[index];
            var title = stock['stockName'] + "  " + stock['stockID'];
                var da = stock['org'];
                window.location.href="orgDetail.html?"+da;
        });
    });
});
