moneytree.directive('onFinishRenderFilters', function($timeout) {
    return {
        restrict: 'A',
        link: function(scope, element, attr) {
            if (scope.$last === true) {
                $timeout(function() {
                    scope.$emit('ngRepeatFinished');
                });
            }
        }
    };
});
moneytree.controller('SeatCtrl', function($scope, $route, $location) {
	 window.sessionStorage.setItem('ert',1);
	var deviceReady = function() {
		Connector.execute({
			service: "DispatcherService",
			action: "changeSkin",
			arguments : ["selector_diagnosis/detail/index.html?type=1",""],
			success: function(data){if(data==2){$('head').append('<link href="assets/css/black.css" rel="stylesheet" type="text/css" />');}}
		});
		var handleSuccessone = function(data) {
			 $('.loading').hide();
             $scope.$apply(function() {
                $scope.stockList = [];
				var isStock=data['result']['isMyStock'];
				if(isStock==1){
				   $('#zixuan').text('已添加').addClass('blockback');
				}
				window.sessionStorage.setItem('isStock',isStock);
				 _.each(data['result']['data'], function(e, i) {
                    var _d = {
                        sellAmount: e['sellAmount'],
                        depName: e['depName'],
                        buyAmount: e['buyAmount'],
                        netAmount: e['netAmount'],
                        sbcs: e['sbcs'],
                        mrcs: e['mrcs'],
						mccs: e['mccs']
                    };
                    $scope.stockList.push(_d);
				 });
            });
		 };
	Connector.request({
            success: handleSuccessone,
            error: function(message) {
			   var cordova = window.cordova;
                cordova.exec(null, null, "DispatcherService", "quit", []);
            },
            before: function() {
                $('.loading').css("display", "-webkit-box");
            },
            url:'GetLHPosition',
            method: "post",
		    data: {
				 'stockID':	stockid,
				 'marketID': marketid,
				 'stockName': stockname,
				 'month':window.sessionStorage.getItem('ert')
			},
            useToken: false
        });
	$(".timeline ul li").click(function(){
	     var oo=$(this).attr('type');
		 if(oo=="one")
		{oo=1;}else if(oo=="two"){oo=3;}else if(oo=="tree"){oo=6;}else if(oo=="four"){oo=12;}
		 window.sessionStorage.setItem('ert',oo); 
	    $(this).addClass('on').siblings().removeClass("on");
		Connector.request({
            success: handleSuccessone,
            error: function(message) {
			   var cordova = window.cordova;
                cordova.exec(null, null, "DispatcherService", "quit", []);
            },
            before: function() {
                $('.loading').css("display", "-webkit-box");
            },
            url:'GetLHPosition',
            method: "post",
		    data: {
				 'stockID':stockid,
				 'marketID': marketid,
				 'stockName':stockname,
				 'month':oo 
			},
            useToken: false
        });
		$('.datetable .tables').hide().eq($(this).index()).show();
		
	  })
} ;
   $scope.$on('$routeChangeSuccess', function() {
      $scope.routePath = $route.current.routePath;
  });
	var query = window.location.search.slice();
	query = query.substring(1, query.length);
	query = decodeURI(query);
	var data1 = query.split("&");
	var stockid = data1[0].split("=")[1];
	var marketid = data1[1].split("=")[1];
	var stockname = data1[2].split("=")[1];	
    Connector.deviceReady(deviceReady);
    Connector.load();
   $('.longhu').click(function(){
	   var da = "stockID=" + stockid + "&marketID=" + marketid + "&stockName=" + stockname;
	  window.location.href="seat1.html?"+da;
	})
	$('.btn #chakan').on('click', function(e) {
		var index = 0;
		var stList = [{stockID: stockid ,stockName: stockname ,marketID: marketid}];
			Connector.execute({
                service: "DispatcherService",
                action: "viewStockDetail",
                arguments: [stockid, parseInt(marketid, 10), index, stList]
            });
	});
	$('.btn #zixuan').on('click', function(e) {
		var isstock=window.sessionStorage.getItem('isStock');
		if(isstock==0){
			Connector.request({
               success: function(data){
				        $('#zixuan').text('已添加').addClass('blockback');
				        $('.showTit').show(1000).text('您已经添加成功!');
						isstock=1;
						window.sessionStorage.setItem('isStock',isstock);
				        setInterval(function(){$('.showTit').hide();},3000);
			},
            error: function(message) {
		        var cordova = window.cordova;
                cordova.exec(null, null, "DispatcherService", "quit", []);
            },
            url:'AddUserStock',
            method: "post",
            data: {
				 "list":{
					 'marketID':marketid,
			  	     'stockID':stockid,
				     'sort':0
					 }
				},
           useToken: true
        });
   }
   else{
	 return false;
	}
});
});

