$(document).ready(function() {
    var deviceReady = function() {
		Connector.execute({
			service: "DispatcherService",
			action: "changeSkin",
			arguments : ["selector_diagnosis/detail/index.html?type=1",""],
			success: function(data){if(data==2){$('head').append('<link href="assets/css/black.css" rel="stylesheet" type="text/css" />');}}
		});
	}
    Connector.deviceReady(deviceReady);
    Connector.load();
    //var imagePath  = $("#imagePath").val();
    //console.log(imagePath);
    var m = 6; //随机表情的数量 
    var numRand = Math.floor(Math.random() * m + 1);
    //$('#frontimg').attr('src','assets/images/front/front_'+numRand+'.png');
    //$('#badimg').attr('src','assets/images/bad/bad_'+numRand+'.png');
    //$('#midimg').attr('src','assets/images/mid/mid_'+numRand+'.png');
    //$('#buyimg').attr('src','assets/images/buy/buy_'+numRand+'.png');
    //$('#sellimg').attr('src','assets/images/sell/sell_'+numRand+'.png');

    var errorMsg = $('#errorMsg').val();
    /*if(null !=errorMsg && "" != errorMsg){
        $('body').showAlert({text : errorMsg});     
    }*/
    $('.extremeStock a').click(function() {
        $(this).addClass('gearry').next('.imght.hide').removeClass('hide');
    });
    $('#searchText').focus(function() {
		$('.jinrizg').hide();
        if ($('#topOrBottom').val() == 'buttom') {} else if ($('#topOrBottom').val() == 'top' && $('#ready').val() == 'yes') {
            $("#search").addClass('buttom');
            $('.extreme').removeClass('hide');
            $('#textButton').html($("#searchText").val());
            $('#textButton').removeClass('hide');
            $('#searchText').css('display', 'none');
            $('#textButton').css('display', 'inline-block');
            $('#topOrBottom').val('buttom');

        };

    });

    $('#textButton').click(function(event) {
        location.reload();
    });

    $('#searchBtn').click(function() {
		$("#search").css({'bottom':'10px'});
		$('.loghicon').hide();
		$('#searchBtn').css({'height':'40px'});
});
    $("#searchText").autocomplete('forGetObjs', {
        //autoFill: false,
        selectFirst: true,
        max: 20,
        minChars: 0,
        matchContains: true,
        scroll: true,
        parse: function(data) {
            return $.map(eval(data), function(row) {
                return {
                    data: row,
                    value: row.dataID + " " + row.name,
                    result: row.dataID + " " + row.name
                }
            });
        },
        formatItem: function(data, i, total) {
            var marketID = data.marketID;
            if (marketID == 0) {
                marketID = 'SH';
            } else if (marketID == 1) {
                marketID = 'SZ';
            }
            return data.dataID + "." + marketID + " " + data.name;
        },
        formatMatch: function(data, i, total) {
            return data.dataID + " " + data.name;
        },
        formatResult: function(data, value) {
            return data.name;
        }
    }).result(function(event, data, formatted) {
        console.log('callback'); //回调
    });

    $("#searchBtn").click(function() {
        extremeDiagnose();
    });
});

function extremeDiagnose() {
    var search = $("#searchText").val();
    if (search.match(/^[0-9]{6}/)) {
        var stockId = search.match(/^[0-9]{6}/);
        /*var marketID = $('li')[0].innerHTML.split(".")[1].split(" ")[0];
        if (marketID == 'SH')
            marketID = 0;
        else if (marketID == 'SZ')
            marketID = 1;*/
        var marketID = stockId.toString().charAt(0);
        if (marketID == 6) {
            marketID = 0;
        } else if (marketID == 0 || marketID == 3) {
            marketID = 1;
        }
        var stock = stockId + '.' + marketID;
        var url = 'ExtremeDiagnose';
        Connector.request({
            success: function(data) {
                var result = data['result']['extremeData'];
                var auth = result['auth'];
                var code = result['code'];
                var stockname = result['stockname'];
                var score = result['score'];
                var rank = result['rank'];
                var rankLevel = (function() {
                    var level = '';
                    if (result['rank'] < 1) {
                        level = '暂无排名';
                    } else if (result['rank'] > 0 && result['rank'] < 100) {
                        level = '排名靠前';
                    } else if (result['rank'] >= 100 && result['rank'] < 1000) {
                        level = '排名中游';
                    } else if (result['rank'] >= 1000) {
                        level = '排名不佳';
                    }
                    return level;
                })();
                var comment = result['comment'];
                var mainProfit = result['mainProfit'];
                var mainBuy = result['mainBuy'];
                var pubProfit = result['pubProfit'];
                var pubBuy = result['pubBuy'];
                var position = result['position'];
                var buyMsg = (function() {
                    var msg = '主力';
                    if (result['mainProfit'] > 0) {
                        msg +='买入' + '<span style="color:red">' + result['mainBuy'].toFixed(2) + '</span>' + '万,净买入' + '<span style="color:red">' + Math.abs(result['mainProfit'].toFixed(2)) + '</span>' + '万;';
                    } else if (result['mainProfit'] <= 0) {
                        msg += '卖出' + '<span style="color:green">' + result['mainBuy'].toFixed(2) + '</span>' + '万,净卖出' + '<span style="color:green">' + Math.abs(result['mainProfit'].toFixed(2)) + '</span>' + '万;';
                    }
                    if (result['pubProfit'] > 0) {
                        msg += '散户买入' + '<span style="color:red">' + result['pubBuy'].toFixed(2) + '</span>' + '万,净买入' + '<span style="color:red">' + Math.abs(result['pubProfit'].toFixed(2)) + '</span>' + '万,';
                    } else if (result['pubProfit'] <= 0) {
                        msg += '散户卖出' + '<span style="color:green">' + result['pubBuy'].toFixed(2) + '</span>' + '万,净卖出' + '<span style="color:green">' + Math.abs(result['pubProfit'].toFixed(2)) + '</span>' + '万,';
                    }
                    if (result['mainProfit'] > 0) {
                        msg += '咦,大家都在买.';
                    } else if (result['mainProfit'] <= 0) {
                        msg += '哎,大家都在抛.';
                    }
                    return msg;
                })();
                var resultrank = '我的' + stockname + '(' + code + '),经测得分' + '<span style="color:red">' + score + '</span>' + ',位列第' + '<span style="color:red">' + rank + '</span>' + '名,' + rankLevel + '';
                document.getElementById('randtext').innerHTML = resultrank;
                document.getElementById('comment').innerHTML = comment;
                document.getElementById('buy').innerHTML = buyMsg;
                document.getElementById('knowmore').innerHTML ='摇钱术技术指标处于' + '<span style="color:green">' + position + '</span>';
                $('#ready').val('yes');
                $('#searchText').focus();
            },
            error: function(message) {
                var cordova = window.cordova;
                cordova.exec(null, null, "DispatcherService", "quit", []);
            },
            url: url,
            method: "post",
            data: {
                stockID: stock
            },
            useToken: false
        });
    } else {
        alert('请填写正确的股票代码');
    }
}

function selectInputContent(id) {
    obj = document.getElementById(id);
    obj.focus();
    obj.select();
}
